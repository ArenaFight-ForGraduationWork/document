#pragma once
#include <WinSock2.h>
#include <Windows.h>
#include <stdio.h>
#include <set>
#include <vector>
#include <iostream>
#include <thread>
#include<time.h>
#include "queue"
#include "protocol.h"

struct network_info {
	WSAOVERLAPPED overlapped;
	SOCKET s;
	BYTE io_type;
	WSABUF wsabuf;
	char IOCPbuf[MAX_PACKET_SIZE];
	char PacketBuf[MAX_PACKET_SIZE];
	int prev_data_size;
	int curr_packet_size;
	WORD iocp_caller_id;
};

struct player_key {
	bool w = false;
	bool s = false;
	bool a = false;
	bool d = false;
	bool space = false;
	bool one = false;
	bool two = false;
	bool three = false;
};

class Player {
public:
	bool in_use;
	std::mutex locking;
	network_info overlapped_ex;
	std::set<int> view_list;
	int id;
	float x = 5;
	float z = 5;
	float bossdirection = 180;
	float direction;
	int time = 0;
	BYTE dir;
	int bosshp = 100;
	player_key key;
	int target;
	int status = BOSS_NORMAL;
	bool move_on = false;
	int boss_skill_time = GetTickCount();
	int player_skill_time = GetTickCount();
	double Distance(Player& p)
	{
		double dx = x - p.x;
		double dy = z - p.z;
		return dx * dx + dy * dy;
	}
	int findNearestPoint();

	void move(Player& p) {
		if (p.x > x) {
			x += 9;
		}
		else if (p.x < x) {
			x -= 9;
		}
		if (p.z > z) {
			z += 9;
		}
		else if (p.z < z) {
			z -= 9;
		}
	}
	void attack() {

	}
};

using namespace std;
extern HANDLE IOCP;
extern Player players[1000];
extern Player boss;
extern Player object[10];

extern vector<int> move_thread;
// ���� �Լ� ���� ��� �� ����
void err_quit(char *msg);

// ���� �Լ� ���� ���
void err_display(char *msg);



int GetNewClientID();
bool in_range(int a, int b);
void Send_Packet(void *packet, unsigned id);
void send_remove_player(int to, int id);

BOOL boss_Aggro(Player& p, Player& b);
BOOL boss_attack_Aggro(Player& p, Player& b);


struct event_type {
	int obj_id;
	unsigned wakeup_time;
	int event_id;
	int caller_id;
};


class mycomparison
{
	bool reverse;
public:
	mycomparison() {}
	bool operator() (const event_type lhs, const event_type rhs) const
	{
		return (lhs.wakeup_time > rhs.wakeup_time);
	}
};


extern mutex timer_lock;
extern priority_queue<event_type, vector<event_type>, mycomparison> timer_queue;



void npc_init();
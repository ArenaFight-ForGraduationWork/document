#pragma once
#include "protocol.h"
#include "val.h"
using namespace std;

mutex tmp;

void Timer_Thread_Start()
{
	while (true) {
		Sleep(1);
		timer_lock.lock();
		while (false == timer_queue.empty()) {
			if (timer_queue.top().wakeup_time > GetTickCount()) break;
			event_type ev = timer_queue.top();
			timer_queue.pop();
			timer_lock.unlock();
			network_info *over = new network_info;
			over->io_type = ev.event_id;
			PostQueuedCompletionStatus(IOCP, 1,
				ev.obj_id,
				&(over->overlapped));
			timer_lock.lock();
		}
		timer_lock.unlock();
	}
}

void send_boss_pos() {
	for (int i = 0; i < 4; ++i) {
		if (players[i].in_use == true) {
			player_position pos_packet;
			pos_packet.size = sizeof(pos_packet);
			pos_packet.type = BOSS_POS;
			pos_packet.x = boss.x;
			pos_packet.z = boss.z;
			pos_packet.distance = 9;
			pos_packet.id = boss.id;
			Send_Packet(&pos_packet, i);
		}
	}
}

void send_boss_attack() {
	for (int i = 0; i < 4; ++i) {
		if (players[i].in_use == true) {
			boss_attack boss_attack_packet;
			boss_attack_packet.size = sizeof(boss_attack_packet);
			boss_attack_packet.type = SC_BOSS_ATTACK;
			boss_attack_packet.id = boss.id;
			boss_attack_packet.attack_type = BOSS_NORMAL_ATTACK;
			boss_attack_packet.attack_type = BOSS_SKILL3;

			Send_Packet(&boss_attack_packet, i);
		}
	}
}

//void ai_thread() {
//	while (1) {
//		int s = rand() % 30;
//		printf("s:%d\n", s);
//		switch (rand() % 4 + 1) {
//		case 1:
//		{
//			for (int i = 0; i < s; ++i) {
//				if (boss.x > -1) {
//					boss.x -= 10;
//				}
//				else
//					boss.x = 0;
//				Sleep(300);
//				f();
//			}
//			break;
//		}
//		case 2:
//		{
//			for (int i = 0; i < s; ++i) {
//
//				if (boss.x < 500) {
//					boss.x += 10;
//				}
//				else
//					boss.x = 499;
//				Sleep(300);
//				f();
//			}
//			break;
//		}
//		case 3:
//		{
//			for (int i = 0; i < s; ++i) {
//
//				if (boss.z > -1) {
//					boss.z -= 10;
//				}
//				else
//					boss.z = 0;
//				Sleep(300);
//				f();
//			}
//			break;
//		}
//		case 4:
//		{			
//			for (int i = 0; i < s; ++i) {
//				if (boss.z < 500) {
//					boss.z += 10;
//				}
//				else
//					boss.z = 499;
//				Sleep(300);
//				f();
//			}
//			break;
//		}
//		default:
//			break;
//		}
//		Sleep(300);
//	}
//}

void ai_thread() {
		if (players[0].in_use == true) {
			switch (boss.status) {
			case BOSS_NORMAL:
				for (int i = 0; i < 2; ++i) {
					if (players[i].in_use == true) {
						if (boss_Aggro(players[i], boss) == TRUE) {
							boss.target = players[i].id;
							boss.status = BOSS_MOVE;
							break;
						}
					}
				}
				break;
			case BOSS_MOVE:
				boss.move(players[boss.target]);
				//tmp.lock();
				for (int i = 0; i < 4; ++i) {
					if (players[i].in_use == true) {
						player_position pos_packet;
						pos_packet.size = sizeof(pos_packet);
						pos_packet.type = BOSS_POS;
						pos_packet.x = boss.x;
						pos_packet.z = boss.z;
						pos_packet.distance = 9;
						pos_packet.id = boss.id;
						pos_packet.direction = players[boss.target].direction + 180;
						Send_Packet(&pos_packet, i);
					}
				}
				//tmp.unlock();
				for (int i = 0; i < 2; ++i) {
					if (players[i].in_use == true) {
						if (boss_attack_Aggro(players[i], boss) == true) {
							boss.target = players[i].id;
							boss.status = BOSS_ATTACK;
							break;
						}
					}
				}
				break;
			case BOSS_ATTACK:
				if (boss_attack_Aggro(players[boss.target], boss) == false) {
					boss.status = BOSS_MOVE;
				}
				else {
					if (boss.boss_skill_time <= GetTickCount()) {
						//cout << "������ ���� Ÿ�� : " << boss.target << endl;
						//tmp.lock();
						boss_attack boss_attack_packet;
						int d = rand() % 3;
						if (d == 0)  boss_attack_packet.attack_type = BOSS_NORMAL_ATTACK;
						else if (d == 1)  boss_attack_packet.attack_type = BOSS_SKILL1;
						else if (d == 2)  boss_attack_packet.attack_type = BOSS_SKILL2;

						for (int i = 0; i < 4; ++i) {
							if (players[i].in_use == true) {
								
								boss_attack_packet.size = sizeof(boss_attack_packet);
								boss_attack_packet.type = SC_BOSS_ATTACK;
								boss_attack_packet.id = boss.id;
								//boss_attack_packet.attack_type = BOSS_NORMAL_ATTACK;
								//boss_attack_packet.attack_type = BOSS_SKILL3;

								Send_Packet(&boss_attack_packet, i);
							}
						}
						//tmp.unlock();
						boss.boss_skill_time = GetTickCount() + 3000;
					}
				}
				break;
			}
		}
		if (boss.bosshp > 0) {
			timer_lock.lock();
			timer_queue.push(event_type{ 1000, GetTickCount() + 50, IO_BOSS });
			timer_lock.unlock();
		}
}

void player_move_thread(int id) {
	if (players[id].in_use == false)
		return;
	if (players[id].move_on == false)
		return;
	if (players[id].time <= GetTickCount()) {
		if (players[id].key.w == true) {
			players[id].z += 5;
		}
		if (players[id].key.s == true) {
			players[id].z -= 5;
		}
		if (players[id].key.a == true) {
			players[id].x -= 5;
		}
		if (players[id].key.d == true) {
			players[id].x += 5;
		}

		player_position pos_packet;

		pos_packet.size = sizeof(pos_packet);
		pos_packet.type = PLAYER_POS;
		pos_packet.x = players[id].x;
		pos_packet.z = players[id].z;
		pos_packet.id = id;
		pos_packet.move_type = players[id].dir;


		//tmp.lock();
		/*for (int j = 0; j < 4; ++j) {
			if (players[j].in_use == true) {
				Send_Packet(&pos_packet, j);
			}
		}*/
		if (players[0].in_use == true) {
			Send_Packet(&pos_packet, 0);
		}
		if (players[1].in_use == true) {
			Send_Packet(&pos_packet, 1);
		}
		//tmp.unlock();
		players[id].time = GetTickCount() + 5;
		timer_lock.lock();
		timer_queue.push(event_type{ (int)id, GetTickCount() + 5, IO_PLAYER_MOVE });
		timer_lock.unlock();
	}
}

			
void Process_Packet (char *packet, unsigned id) {
	switch (packet[1]) {
	case PLAYER_MOV:
	{
		packet_player_move *player_move_packet = reinterpret_cast<packet_player_move *>(packet);
		players[id].dir = player_move_packet->move_type;

		if (players[id].dir == W) {
			players[id].key.w = true;
			players[id].z += 5;
			if (players[id].key.s == true)
				players[id].z -= 5;
			if (players[id].key.a == true)
				players[id].x -= 5;
			if (players[id].key.d == true)
				players[id].x += 5;
		}
		if (players[id].dir == S) {
			players[id].key.s = true;
			players[id].z -= 5;
			if (players[id].key.w == true)
				players[id].z += 5;
			if (players[id].key.a == true)
				players[id].x -= 5;
			if (players[id].key.d == true)
				players[id].x += 5;
		}
		if (players[id].dir == A) {
			players[id].key.a = true;
			players[id].x -= 5;
			if (players[id].key.w == true)
				players[id].z += 5;
			if (players[id].key.s == true)
				players[id].z -= 5;
			if (players[id].key.d == true)
				players[id].x += 5;
		}
		if (players[id].dir == D) {
			players[id].key.d = true;
			players[id].x += 5;
			if (players[id].key.w == true)
				players[id].z += 5;
			if (players[id].key.s == true)
				players[id].z -= 5;
			if (players[id].key.a == true)
				players[id].x -= 5;
		}

		// 1) �÷��̾ ���� Ű ����
		switch (player_move_packet->move_type)
		{
		case W:
			players[id].key.w = true;
			break;
		case S:
			players[id].key.s = true;
			break;
		case A:
			players[id].key.a = true;
			break;
		case D:
			players[id].key.d = true;
			break;
		default:break;
		}

		// 2) ī�޶� �ٶ󺸴� ���� + �Է¹��� ���� = fAngle�� Yaw������ ȸ��
		float defaultAngleX = 0, defaultAngleY = 0, defaultAngleZ = 1;
		float inputAngleX = 0, inputAngleY = 0, inputAngleZ = 0;
		if (players[id].key.w)   inputAngleZ += 1;
		if (players[id].key.s)   inputAngleZ -= 1;
		if (players[id].key.a)   inputAngleX += 1;
		if (players[id].key.d)   inputAngleX -= 1;
		if ((0 == inputAngleX) && (0 == inputAngleZ)) return;   // inputAngle==(0,0,0)�̸� ��� �������ε� �������� �ʴ´� => �Լ� ����
																//float defaultLength = sqrt(defaultAngleX*defaultAngleX + defaultAngleZ*defaultAngleZ);   // �̰� �׳� 1�ε�?
		float defaultLength = 1;
		float inputLength = sqrt(inputAngleX*inputAngleX + inputAngleZ*inputAngleZ);
		//float scalarProduct = defaultAngleX*inputAngleX + defaultAngleY*inputAngleY + defaultAngleZ*inputAngleZ;
		//float scalarProduct = inputAngleZ;
		//float fAngle = acosf(scalarProduct / (defaultLength * inputLength));
		float fAngle = acosf(inputAngleZ / inputLength);
		fAngle = fAngle / 3.141592653589793 * 180.0;
		//fAngle = ((defaultAngleX* inputAngleZ - defaultAngleZ*inputAngleX) > 0.0f) ? fAngle : -fAngle;
		fAngle = ((-inputAngleX) > 0.0f) ? fAngle : -fAngle;

		// 3) �ش� �������� ȸ��, �̵�
		players[id].direction = player_move_packet->direction + fAngle;
		// ������ �Ÿ� : speed * �ð� -> players[id].distance


		player_position pos_packet;

		pos_packet.size = sizeof(pos_packet);
		pos_packet.type = PLAYER_POS;
		pos_packet.distance = 5;
		pos_packet.id = id;
		pos_packet.x = players[id].x;
		pos_packet.z = players[id].z;

		pos_packet.direction = players[id].direction;
		pos_packet.move_type = players[id].dir;

		//tmp.lock();
		for (int j = 0; j < 4; ++j) {
			if (players[j].in_use == true) {
				Send_Packet(&pos_packet, j);
			}
		}
		//tmp.unlock();

	/*	move_thread.push_back(id);
		players[id].time = GetTickCount();
		players[id].dir = player_move_packet->move_type;*/

		/*if (players[id].move_on == false) {
			timer_lock.lock();
			timer_queue.push(event_type{ (int)id, GetTickCount() + 10, IO_PLAYER_MOVE });
			timer_lock.unlock();
			players[id].move_on = true;
		}*/
		break;
	}
	case PLAYER_MOV_END:
	{
		packet_player_move *player_move_packet = reinterpret_cast<packet_player_move *>(packet);		
		players[id].dir = player_move_packet->move_type;

		if (players[id].dir == W) {
			players[id].key.w = false;
		}
		else if (players[id].dir == S) {
			players[id].key.s = false;
		}
		else if (players[id].dir == A) {
			players[id].key.a = false;
		}
		else if (players[id].dir == D) {
			players[id].key.d = false;
		}

		if (players[id].key.w == false && players[id].key.s == false && players[id].key.a == false && players[id].key.w == false) {
			players[id].move_on == false;
			packet_player_move_end end_packet;
			end_packet.id = id;
			end_packet.size = sizeof(end_packet);
			end_packet.type = SC_PLAYER_MOV_END;
			for (int j = 0; j < 4; ++j) {
				if (players[j].in_use == true) {
					if (players[j].id != id) {
						Send_Packet(&end_packet, j);
					}
				}
			}

			//if (players[id].key.w == false && players[id].key.s == false && players[id].key.a == false && players[id].key.w == false) {
			//	for (int i = 0; i < move_thread.size(); ++i) {
			//		if (move_thread[i] == id) {
			//			move_thread.erase(move_thread.begin() + i);
			//		}
			//	}
			//}
		}
		break;
	}
	case PLAYER_ATTACK:
	{
		if (players[id].player_skill_time <= GetTickCount()) {
			player_attack *player_attack_packet = reinterpret_cast<player_attack *>(packet);
			
			player_attack attack_packet;
			attack_packet.size = sizeof(attack_packet);
			attack_packet.type = SC_PLAYER_ATTACK_S;
			attack_packet.id = id;
			attack_packet.attack_type = player_attack_packet->attack_type;
			//cout << "�÷��̾�id:" << id << "�� ������:";
			//printf("Ÿ��:%d\n", attack_packet.attack_type);

				float distance = (players[id].x - boss.x)*(players[id].x - boss.x)
					+ (players[id].z - boss.z)*(players[id].z - boss.z);
				if (sqrt(distance) <= 71.5891 + 357.8060)
				{
					boss.bosshp -= 10;
					//cout << "����hp:%d" << boss.bosshp << endl;
				}
			
				if (boss.bosshp <= 0) {
					boss_dead dead_packet;
					dead_packet.id = 1000;
					dead_packet.size = sizeof(dead_packet);
					dead_packet.type = BOSS_DEAD;
					for (int j = 0; j < 4; ++j) {
						if (players[j].in_use == true) {
								Send_Packet(&dead_packet, j);
						}
					}
				}
			//tmp.lock();
			//Send_Packet(&attack_packet, id);
			/*for (int j = 0; j < 4; ++j) {
				if (players[j].in_use == true) {
					Send_Packet(&attack_packet, j);
				}
			}*/
			if (players[0].in_use == true) {
				Send_Packet(&attack_packet, 0);
			}
			if (players[1].in_use == true) {
				Send_Packet(&attack_packet, 1);
			}
			//tmp.unlock();
			players[id].player_skill_time = GetTickCount() + 1000;
		}
		break;
	}
		default:
			printf ("Invalid Packet Received from Client ID:%d\n", id);
			//exit (-1);
	}
		
}
void Worker_Thread () {
	DWORD IOsize;
	ULONG key;
	network_info *over_ex;
	while (true) {
		GetQueuedCompletionStatus (IOCP, &IOsize, &key, reinterpret_cast<LPOVERLAPPED *>(&over_ex), INFINITE);
		// ERROR ó��
		// ���� ���� ó��
		if (0 == IOsize) {
			remove_player logout_player;
			logout_player.id = key;
			logout_player.size = sizeof (logout_player);
			logout_player.type = REMOVE_PLAYER;
			players[key].in_use = false;
			players[key].locking.lock ();

			players[key].view_list.clear();

			players[key].locking.unlock();
			for (int i = 0; i < MAX_USER; ++i) {
				if (players[i].in_use == true) {
					Send_Packet (&logout_player, i);
				}
			}
			players[key].x = 5;
			players[key].z = 5;
			closesocket (over_ex->s);
			continue;
		}
		if (over_ex->io_type == IO_RECV) {
			int data_to_process = IOsize;
			char * buf = over_ex->IOCPbuf;
			while (0 < data_to_process) {
				if (0 == over_ex->curr_packet_size)
					over_ex->curr_packet_size = buf[0];
				int need_to_build = over_ex->curr_packet_size - over_ex->prev_data_size;
				if (need_to_build <= data_to_process) {
					memcpy (over_ex->PacketBuf + over_ex->prev_data_size, buf, need_to_build);
					Process_Packet (over_ex->PacketBuf, key);
					over_ex->curr_packet_size = 0;
					over_ex->prev_data_size = 0;
					data_to_process -= need_to_build;
					buf += need_to_build;
				}
				else {
					memcpy (over_ex->PacketBuf + over_ex->prev_data_size, buf, data_to_process);
					over_ex->prev_data_size += data_to_process;
					data_to_process = 0;
					buf += data_to_process;
				}
			}
			unsigned long recv_flag = 0;
			WSARecv (over_ex->s, &over_ex->wsabuf, 1, NULL, &recv_flag, &over_ex->overlapped, NULL);
		}
		else if(over_ex->io_type == IO_SEND) {
			delete over_ex;
		}
		else if (over_ex->io_type == IO_BOSS) {
			ai_thread();
			delete over_ex;
		}/*
		else if (over_ex->io_type == IO_PLAYER_MOVE) {
			player_move_thread(key);
			delete over_ex;
		}*/
	}
}

void Accept_Thread () {
	sockaddr_in accept_addr;
	sockaddr_in client_addr;

	SOCKET accept_socket = WSASocket (AF_INET, SOCK_STREAM, IPPROTO_TCP, NULL, 0, WSA_FLAG_OVERLAPPED);

	ZeroMemory (&accept_addr, sizeof (accept_addr));
	accept_addr.sin_family = AF_INET;
	accept_addr.sin_addr.s_addr = htonl (INADDR_ANY);
	accept_addr.sin_port = htons (SERVER_PORT);

	int err = ::bind (accept_socket, reinterpret_cast<sockaddr *>(&accept_addr), sizeof (accept_addr));
	if (SOCKET_ERROR == err) {
		err_display ("bind()");
		//exit (-1);
	}
	err = listen (accept_socket, 10);
	if (SOCKET_ERROR == err) {
		err_display ("listen()");
		//exit (-1);
	}
	while (true) {
		int addr_len = sizeof (accept_addr);
		SOCKET new_socket = WSAAccept (accept_socket, reinterpret_cast<sockaddr *>(&client_addr), &addr_len, NULL, NULL);
		if (INVALID_SOCKET == new_socket) {
			err_display ("accept()");
			//exit (-1);
		}
		int id = GetNewClientID ();
		players[id].overlapped_ex.curr_packet_size = 0;
		players[id].overlapped_ex.io_type = IO_RECV;
		ZeroMemory (&players[id].overlapped_ex.overlapped, sizeof (WSAOVERLAPPED));
		players[id].overlapped_ex.prev_data_size = 0;
		players[id].overlapped_ex.wsabuf.buf = players[id].overlapped_ex.IOCPbuf;
		players[id].overlapped_ex.wsabuf.len = MAX_PACKET_SIZE;
		players[id].id = id;
		players[id].overlapped_ex.s = new_socket;
		players[id].x = 5;
		players[id].z = 5;
		CreateIoCompletionPort (reinterpret_cast<HANDLE>(new_socket), IOCP, id, 0);


		player_position pp_packet;
		pp_packet.id = players[id].id;
		pp_packet.size = sizeof(pp_packet);
		pp_packet.type = PUT_PLAYER;
		pp_packet.x = players[id].x;
		pp_packet.z = players[id].z;
		pp_packet.distance = 5;

		// �� ���� �Դٰ� ��ü �������� �˸�
		for (int i = 0; i < MAX_USER; ++i) {
			if (players[i].in_use == true)
				Send_Packet(&pp_packet, i);
		}

		 // ���� ������ ���� ���� ����

		
		// �� �������� ���� ������ ���� ��� �˸�

		login login_packet;
		login_packet.type = LOGIN;
		login_packet.size = sizeof(login_packet);
		login_packet.id = players[id].id;

		login_packet.bossid = 1000;
		login_packet.bossx = boss.x;
		login_packet.bossy = boss.z;
		login_packet.bossdirection = boss.bossdirection;

		Send_Packet(&login_packet, players[id].id);

		for (int i = 0; i < 10; ++i) {
			if (players[i].in_use == true) {
				login_packet.id = players[i].id;
				login_packet.x = players[i].x;
				login_packet.z = players[i].z;
				Send_Packet(&login_packet, players[id].id);
			}
		}

		players[id].in_use = true;

		unsigned long recv_flag = 0;
		err = WSARecv (new_socket, &players[id].overlapped_ex.wsabuf, 1, NULL, &recv_flag, reinterpret_cast<LPOVERLAPPED>(&players[id].overlapped_ex), NULL);
		if (SOCKET_ERROR == err) {
			int err_code = WSAGetLastError ();
			if (WSA_IO_PENDING != err_code) {
				err_display ("accept()");
				//exit (-1);
			}
		}
		
	}
}

int main (int argc, char *argv[]) {
	const auto THREADS = 6;

	vector <thread *> worker_threads;

	WSADATA wsadata;

	WSAStartup (MAKEWORD (2, 2), &wsadata);

	for (int i = 0; i < MAX_USER; ++i) {
		players[i].in_use = false;
		players[i].overlapped_ex.curr_packet_size = 0;
		players[i].overlapped_ex.io_type = IO_RECV;
		ZeroMemory (&players[i].overlapped_ex.overlapped, sizeof (WSAOVERLAPPED));
		players[i].overlapped_ex.prev_data_size = 0;
		players[i].overlapped_ex.wsabuf.buf = players[i].overlapped_ex.IOCPbuf;
		players[i].overlapped_ex.wsabuf.len = MAX_PACKET_SIZE;
	}
	boss.x = 5;
	boss.z = 2000;
	boss.id = 1000;

	for (int i = 0; i < 10; ++i) {
		object[i].in_use = false;
		object[i].id = 2000 + i;
	}

	IOCP = CreateIoCompletionPort (INVALID_HANDLE_VALUE, NULL, NULL, 0);

	for (int i = 0; i < THREADS; ++i)
		worker_threads.push_back (new thread{Worker_Thread});
	auto accept_thread = thread{Accept_Thread};

	thread timer_thread{ Timer_Thread_Start };


	//auto Move_thread = thread{ player_move_thread };
	//auto boss_thread = thread{ ai_thread };


	timer_lock.lock();
	timer_queue.push(event_type{ 1000, GetTickCount() + 1000, IO_BOSS });
	timer_lock.unlock();

	for (auto t : worker_threads) t->join ();
	accept_thread.join ();


	//Move_thread.join();
	//boss_thread.join();
	return 0;
}
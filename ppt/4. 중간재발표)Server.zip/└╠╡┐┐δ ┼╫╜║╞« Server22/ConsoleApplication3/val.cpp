#include "val.h"

HANDLE IOCP;
Player players[1000];
Player boss;
Player object[10];

vector<int> move_thread;
// ���� �Լ� ���� ��� �� ����
void err_quit(char *msg) {
	LPVOID lpMsgBuf;
	FormatMessage(
		FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM,
		NULL, WSAGetLastError(),
		MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),
		(LPTSTR)&lpMsgBuf, 0, NULL);
	MessageBox(NULL, (LPCTSTR)lpMsgBuf, msg, MB_ICONERROR);
	LocalFree(lpMsgBuf);
	exit(1);
}

// ���� �Լ� ���� ���
void err_display(char *msg) {
	LPVOID lpMsgBuf;
	FormatMessage(
		FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM,
		NULL, WSAGetLastError(),
		MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),
		(LPTSTR)&lpMsgBuf, 0, NULL);
	printf("[%s] %s", msg, (char *)lpMsgBuf);
	LocalFree(lpMsgBuf);
}

int Player::findNearestPoint() {
	double distance = 9999;
	int tmp = 0;
	for (int i = 0; i < 10; ++i) {
		if (players[i].in_use == true) {
			if (distance <= Distance(players[i])) {
				distance = Distance(players[i]);
				//cout << "players " << i << " : " << distance << endl;
				tmp = players[i].id;
			}
		}
	}
	return tmp;
}

int GetNewClientID() {
	for (int i = 0; i < MAX_USER; ++i) {
		if (players[i].in_use) continue;
		return i;
	}
	cout << "MAX USER\n";
	exit(-1);
}
bool in_range(int a, int b)
{
	if (players[b].x - 3 <= players[a].x && players[b].x + 3 >= players[a].x) {
		if (players[b].z - 3 <= players[a].z && players[b].z + 3 >= players[a].z)
			return true;
	}
	return false;

	//return 5 * 4 >=
	//	(players[a].x - players[b].x)*(players[a].x - players[b].x) + (players[a].z - players[b].z)*(players[a].z - players[b].z);
}
void Send_Packet(void *packet, unsigned id) {
	network_info *over_ex = new network_info;
	int packet_size = reinterpret_cast<unsigned char *>(packet)[0];
	//printf("Ÿ��:%d\n", reinterpret_cast<unsigned char *>(packet)[1]);
	/*if (reinterpret_cast<unsigned char *>(packet)[1] <= 0 || reinterpret_cast<unsigned char *>(packet)[1] >= 18) {
		printf("Ÿ��:%d\n", reinterpret_cast<unsigned char *>(packet)[1]);
		return;
	}*/
	memcpy(over_ex->IOCPbuf, packet, packet_size);
	over_ex->io_type = IO_SEND;
	ZeroMemory(&over_ex->overlapped, sizeof(WSAOVERLAPPED));
	over_ex->wsabuf.buf = over_ex->IOCPbuf;
	over_ex->wsabuf.len = packet_size;
	unsigned long IOsize;
	WSASend(players[id].overlapped_ex.s, &over_ex->wsabuf, 1, &IOsize, NULL, &over_ex->overlapped, NULL);
}
void send_remove_player(int to, int id)
{
	remove_player remove_player_packet;
	remove_player_packet.id = players[id].id;
	remove_player_packet.size = sizeof(remove_player);
	remove_player_packet.type = REMOVE_PLAYER;
	Send_Packet(&remove_player_packet, to);
}
BOOL boss_Aggro(Player& p, Player& b) {
	if (p.x + 50 >= b.x - 1500 && p.z + 50 >= b.z - 1500 && p.z - 50 <= b.z + 1500 && p.x - 50 <= b.x + 1500) {
		//cout << "Ʈ��" << endl;
		return TRUE;
	}
	else {
		//cout << "�޽� ";
		//cout << p.x << ", " << p.z << endl;
		return FALSE;
	}
}

BOOL boss_attack_Aggro(Player& p, Player& b) {
	if (p.x + 50 >= b.x - 300 && p.z + 50 >= b.z - 300 && p.z - 50 <= b.z + 300 && p.x - 50 <= b.x + 300) {
		return TRUE;
	}
	else
		return FALSE;
}



mutex timer_lock;
priority_queue<event_type, vector<event_type>, mycomparison> timer_queue;


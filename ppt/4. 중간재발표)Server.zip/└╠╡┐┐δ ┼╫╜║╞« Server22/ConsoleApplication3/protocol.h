#pragma once
#pragma comment(lib, "ws2_32")
#include <winsock2.h>
#include <stdlib.h>
#include <stdio.h>
#include <Windows.h>
#include <mutex>
#include <set>

#define MAX_BUFF_SIZE   4096
#define MAX_PACKET_SIZE  4096

#define MAX_USER 10

#define SERVER_PORT  4000

#define MAX_CHAT_SIZE  100


#define SERVER_PORT  4000

// ������ ����Ű Ȯ��
#define W			1
#define S			2
#define A			3
#define D			4

// �÷��̾� ��ų
#define NORMAL_ATTACK		1
#define PLAYER_SKILL1		2
#define PLAYER_SKILL2		3
#define PLAYER_SKILL3		4

// ���� -> Ŭ��
#define LOGIN			1
#define PUT_PLAYER		2
#define PLAYER_POS		3
#define REMOVE_PLAYER   4
#define CREATE_ROOM_S   5
#define CREATE_ROOM_F   6
#define JOIN_ROOM_S		7
#define JOIN_ROOM_F		8
#define GAME_START_S    9
#define GAME_START_F    10
#define CHATTING	    11
#define ROOM_PUT_PLAYER 12
#define OUT_ROOM		13
#define BOSS_POS		14
#define SC_PLAYER_ATTACK	15
#define SC_BOSS_ATTACK		16
#define SC_PLAYER_ATTACK_S	17
#define SC_PLAYER_MOV_END	18
#define BOSS_DEAD			19

// Ŭ�� -> ����
#define CREATE_ROOM		1
#define JOIN_ROOM		2
#define PLAYER_MOV      3
#define ROOM_EXIT		4
#define GAME_START		5
#define LOBBY_CHAT		6
#define ROOM_CHAT		7
#define PLAYER_MOV_END	8
#define PLAYER_ATTACK	9


#define LOBBY 1
#define ROOM  2
#define FIGHT 3

#define IO_SEND 1
#define IO_RECV 2
#define IO_BOSS  3
#define IO_PLAYER_MOVE 4

// ��������
#define BOSS_NORMAL	1
#define BOSS_MOVE	2
#define BOSS_ATTACK	3

// ��������
#define BOSS_NORMAL_ATTACK 1
#define BOSS_SKILL1 2
#define BOSS_SKILL2 3
#define BOSS_SKILL3 4


#pragma pack (push, 1)
struct login {
	BYTE size;
	BYTE type;
	int id;
	float x;
	float z;
	int bossid;
	float bossx;
	float bossy;
	float direction;
	float bossdirection;
};
struct packet_player_move {
	BYTE size;
	BYTE type;
	BYTE move_type;
	float direction;
};
struct packet_player_move_end {
	BYTE size;
	BYTE type;
	int id;
};
struct player_position {
	BYTE size;
	BYTE type;
	int id;
	float x;
	float z;
	float distance;
	BYTE move_type;
	float direction;
};
struct put_player {
	BYTE size;
	BYTE type;
	int id;
	float x;
	float z;
	float distance;
	BYTE move_type;
	float direction;
};
struct remove_player {
	BYTE size;
	BYTE type;
	int id;
};
struct player_attack {
	BYTE size;
	BYTE type;
	int id;
	BYTE attack_type;
};
struct boss_attack {
	BYTE size;
	BYTE type;
	BYTE attack_type;
	int id;
};
struct boss_dead {
	BYTE size;
	BYTE type;
	int id;
};
#pragma pack (pop)
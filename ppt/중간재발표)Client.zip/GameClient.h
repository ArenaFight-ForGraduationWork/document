#ifndef GAMECLIENT_H_
#define GAMECLIENT_H_

#include "resource.h"




#endif